import time
import random
import threading
import win32gui
import win32con
import win32api

running = True

def audio_effect():
    sound_types = [win32con.MB_ICONHAND, win32con.MB_ICONQUESTION, win32con.MB_ICONEXCLAMATION, win32con.MB_ICONASTERISK]
    while running:
        try:
            win32api.MessageBeep(random.choice(sound_types))
        except:
            pass
        time.sleep(random.uniform(0.2, 0.8))

def gdi_visual_effects():
    hdc = win32gui.GetDC(0)
    screen_w = win32api.GetSystemMetrics(win32con.SM_CXSCREEN)
    screen_h = win32api.GetSystemMetrics(win32con.SM_CYSCREEN)
    error_icon = win32gui.LoadIcon(0, win32con.IDI_ERROR)

    while running:
        if random.random() < 0.4:
            win32gui.DrawIcon(hdc, random.randint(0, screen_w), random.randint(0, screen_h), error_icon)
        if random.random() < 0.6:
            y_pos = random.randint(0, screen_h)
            shift_dist = random.randint(-15, 15)
            line_height = random.randint(10, 50)
            win32gui.BitBlt(hdc, shift_dist, y_pos, screen_w, line_height, hdc, 0, y_pos, win32con.SRCCOPY)
        if random.random() < 0.05:
            win32gui.BitBlt(hdc, 0, 0, screen_w, screen_h, hdc, 0, 0, win32con.DSTINVERT)
        time.sleep(0.02)
    win32gui.ReleaseDC(0, hdc)

if __name__ == "__main__":
    print("Running INFINITE MEMZ GDI Simulator... Press Ctrl+C inside this window to exit.")
    t1 = threading.Thread(target=audio_effect, daemon=True)
    t2 = threading.Thread(target=gdi_visual_effects, daemon=True)
    t1.start()
    t2.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        running = False
        time.sleep(0.5)
        win32gui.RedrawWindow(0, None, None, win32con.RDW_INVALIDATE | win32con.RDW_ERASE | win32con.RDW_ALLCHILDREN)
        print("Stopped and cleaned up.")
