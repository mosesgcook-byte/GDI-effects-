import time
import math
import random
import threading
import win32gui
import win32con
import win32api

running = True

def sigma_audio_sweep():
    sound_types = [win32con.MB_ICONEXCLAMATION, win32con.MB_ICONASTERISK, win32con.MB_ICONHAND, win32con.MB_ICONQUESTION]
    t = 0.0
    while running:
        try:
            win32api.MessageBeep(sound_types[int(t) % len(sound_types)])
        except: pass
        time.sleep(0.1 + 0.3 * (1.0 + math.sin(t)))
        t += 0.4

def sigma_gdi_payloads():
    hdc = win32gui.GetDC(0)
    screen_w = win32api.GetSystemMetrics(win32con.SM_CXSCREEN)
    screen_h = win32api.GetSystemMetrics(win32con.SM_CYSCREEN)
    error_icon = win32gui.LoadIcon(0, win32con.IDI_ERROR)
    iteration = 0.0

    while running:
        iteration += 0.05
        if random.random() < 0.85:
            for y_block in range(0, screen_h, 30):
                wave_shift = int(25 * math.sin(iteration + (y_block * 0.005)))
                win32gui.BitBlt(hdc, wave_shift, y_block, screen_w, 30, hdc, 0, y_block, win32con.SRCCOPY)
        if random.random() < 0.15:
            win32gui.BitBlt(hdc, 0, 0, screen_w, screen_h, hdc, 0, 0, win32con.NOTSRCCOPY)
        if random.random() < 0.45:
            cx, cy = screen_w // 2, screen_h // 2
            r = min(screen_w, screen_h) // 3
            ix = int(cx + r * math.cos(iteration * 2) + random.randint(-50, 50))
            iy = int(cy + r * math.sin(iteration * 2) + random.randint(-50, 50))
            win32gui.DrawIcon(hdc, ix, iy, error_icon)
        if random.random() < 0.08:
            win32gui.StretchBlt(hdc, 10, 10, screen_w - 20, screen_h - 20, hdc, 0, 0, screen_w, screen_h, win32con.SRCCOPY)
        time.sleep(0.01)
    win32gui.ReleaseDC(0, hdc)

if __name__ == "__main__":
    print("Running INFINITE Sigma GDI Simulator... Press Ctrl+C inside this window to exit.")
    t1 = threading.Thread(target=sigma_audio_sweep, daemon=True)
    t2 = threading.Thread(target=sigma_gdi_payloads, daemon=True)
    t1.start()
    t2.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt: pass
    finally:
        running = False
        time.sleep(0.5)
        win32gui.RedrawWindow(0, None, None, win32con.RDW_INVALIDATE | win32con.RDW_ERASE | win32con.RDW_ALLCHILDREN)
        print("Stopped and cleaned up.")
