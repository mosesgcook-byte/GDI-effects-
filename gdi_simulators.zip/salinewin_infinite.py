import time
import math
import random
import threading
import win32gui
import win32con
import win32api
import winsound

running = True

def salinewin_bytebeat():
    t = 0
    while running:
        pitch = int((t & (t >> 8 | t >> 16) ^ t) & 0xFF)
        freq = 100 + (pitch * 7)
        if 37 <= freq <= 32767:
            try: winsound.Beep(freq, 40)
            except: pass
        t += 1
        time.sleep(0.005)

def salinewin_gdi_payloads():
    hdc = win32gui.GetDC(0)
    screen_w = win32api.GetSystemMetrics(win32con.SM_CXSCREEN)
    screen_h = win32api.GetSystemMetrics(win32con.SM_CYSCREEN)
    p1 = win32gui.CreatePen(win32con.PS_SOLID, 3, win32api.RGB(0, 255, 100))
    p2 = win32gui.CreatePen(win32con.PS_SOLID, 2, win32api.RGB(0, 200, 255))
    iteration = 0

    while running:
        iteration += 1
        if iteration % 4 == 0:
            win32gui.BitBlt(hdc, 0, 0, screen_w, screen_h, hdc, 0, 0, win32con.DSTINVERT)
        old = win32gui.SelectObject(hdc, p1 if iteration % 2 == 0 else p2)
        cx, cy = screen_w // 2, screen_h // 2
        offset = int(200 * math.sin(iteration * 0.1))
        win32gui.MoveToEx(hdc, cx - offset, 0)
        win32gui.LineTo(hdc, cx + offset, screen_h)
        win32gui.MoveToEx(hdc, 0, cy - offset)
        win32gui.LineTo(hdc, screen_w, cy + offset)
        win32gui.SelectObject(hdc, old)
        if random.random() < 0.40:
            bw, bh = random.randint(100, 400), random.randint(100, 400)
            sx = random.randint(0, screen_w - bw)
            sy = random.randint(0, screen_h - bh)
            win32gui.BitBlt(hdc, sx + random.randint(-20, 20), sy + random.randint(-20, 20), bw, bh, hdc, sx, sy, win32con.SRCINVERT)
        time.sleep(0.02)
    win32gui.DeleteObject(p1)
    win32gui.DeleteObject(p2)
    win32gui.ReleaseDC(0, hdc)

if __name__ == "__main__":
    print("Running INFINITE Salinewin Simulator... Press Ctrl+C inside this window to exit.")
    t1 = threading.Thread(target=salinewin_bytebeat, daemon=True)
    t2 = threading.Thread(target=salinewin_gdi_payloads, daemon=True)
    t1.start()
    t2.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt: pass
    finally:
        running = False
        time.sleep(0.5)
        win32gui.RedrawWindow(0, None, None, win32con.RDW_INVALIDATE | win32con.RDW_ERASE | win32con.RDW_ALLCHILDREN)
        print("Stopped and cleaned up.")
