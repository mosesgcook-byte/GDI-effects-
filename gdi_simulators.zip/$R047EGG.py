import time
import math
import random
import threading
import win32gui
import win32con
import win32api

# Global lifecycle control flag
running = True

def chaotic_audio_blast():
    """Generates a rapid, overlapping barrage of system alert sounds."""
    sound_types = [
        win32con.MB_ICONHAND,        # Critical Stop
        win32con.MB_ICONEXCLAMATION,  # Warning
        win32con.MB_ICONASTERISK,     # Information
        win32con.MB_ICONQUESTION     # Question
    ]
    while running:
        # Rapidly trigger random overlapping alerts
        chosen_sound = random.choice(sound_types)
        win32api.MessageBeep(chosen_sound)
        
        # Extremely short delay to simulate heavy audio distortion
        time.sleep(random.uniform(0.05, 0.2))

def chaotic_gdi_payloads():
    """Combines multiple extreme visual distortions running at maximum speed."""
    hdc = win32gui.GetDC(0)
    screen_w = win32api.GetSystemMetrics(win32con.SM_CXSCREEN)
    screen_h = win32api.GetSystemMetrics(win32con.SM_CYSCREEN)
    
    # Load standard error visual markers
    error_icon = win32gui.LoadIcon(0, win32con.IDI_ERROR)
    warning_icon = win32gui.LoadIcon(0, win32con.IDI_WARNING)

    iteration = 0.0
    while running:
        iteration += 0.2  # High acceleration rate for math modifiers

        # 1. Multi-Directional Screen Melting / Tearing
        if random.random() < 0.90:
            # Shred the screen into tiny horizontal blocks and shear them aggressively
            for y_block in range(0, screen_h, 15):
                wave_shift = int(50 * math.sin(iteration + (y_block * 0.01)))
                win32gui.BitBlt(
                    hdc, wave_shift, y_block, screen_w, 15, 
                    hdc, 0, y_block, win32con.SRCCOPY
                )

        # 2. Extreme Screen Shaking (Horizontal & Vertical Jitter)
        if random.random() < 0.70:
            jitter_x = random.randint(-30, 30)
            jitter_y = random.randint(-30, 30)
            win32gui.BitBlt(
                hdc, jitter_x, jitter_y, screen_w, screen_h, 
                hdc, 0, 0, win32con.SRCCOPY
            )

        # 3. Rapid Full-Screen Inversion Strobe
        if random.random() < 0.25:
            win32gui.BitBlt(
                hdc, 0, 0, screen_w, screen_h, 
                hdc, 0, 0, win32con.NOTSRCCOPY
            )

        # 4. Rapid Spiral Icon Swarms
        if random.random() < 0.80:
            center_x, center_y = screen_w // 2, screen_h // 2
            # Swirl radius constantly expands and contracts
            radius = int((screen_h // 3) * abs(math.sin(iteration)))
            
            icon_x = int(center_x + radius * math.cos(iteration * 3))
            icon_y = int(center_y + radius * math.sin(iteration * 3))
            
            # Alternate rapidly between error and warning markers
            active_icon = error_icon if int(iteration) % 2 == 0 else warning_icon
            win32gui.DrawIcon(hdc, icon_x, icon_y, active_icon)
            
            # Also drop random icons completely scattered
            win32gui.DrawIcon(hdc, random.randint(0, screen_w), random.randint(0, screen_h), active_icon)

        # 5. Fracturing Tunnel Shrink Effect
        if random.random() < 0.15:
            win32gui.StretchBlt(
                hdc, -20, -20, screen_w + 40, screen_h + 40,
                hdc, 0, 0, screen_w, screen_h, win32con.SRCCOPY
            )

        # Minimal sleep interval to maximize performance load and visual speed
        time.sleep(0.005)

    win32gui.ReleaseDC(0, hdc)

if __name__ == "__main__":
    print("WARNING: Launching High-Intensity Chaotic GDI Sandbox...")
    print("Press Ctrl+C directly inside this terminal window to kill the effect loop safely.")
    
    audio_stream = threading.Thread(target=chaotic_audio_blast, daemon=True)
    visual_stream = threading.Thread(target=chaotic_gdi_payloads, daemon=True)
    
    audio_stream.start()
    visual_stream.start()

    try:
        # Run the full intense sequence for 15 seconds
        for _ in range(150):
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\nManually intercepting execution...")
    finally:
        running = False
        time.sleep(0.4)
        
        # Complete environment wipe to restore normal desktop layout
        win32gui.RedrawWindow(
            0, None, None, 
            win32con.RDW_INVALIDATE | win32con.RDW_ERASE | win32con.RDW_ALLCHILDREN | win32con.RDW_UPDATENOW
        )
        print("Sandbox closed cleanly. Desktop composition refreshed.")
